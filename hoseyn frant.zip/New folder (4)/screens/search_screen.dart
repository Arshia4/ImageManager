import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../models/image_item.dart';
import 'image_details_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _queryController = TextEditingController();
  List<ImageItem> _searchResults = [];
  bool _isLoading = false;

  Future<void> _search() async {
    if (_queryController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('لطفاً یک کلمه برای جستجو وارد کنید')),
      );
      return;
    }

    setState(() => _isLoading = true);

    final appState = Provider.of<AppState>(context, listen: false);
    final results = await appState.searchImages(_queryController.text);

    setState(() {
      _searchResults = results;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('جستجوی عکس')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _queryController,
                    decoration: const InputDecoration(
                      labelText: 'جستجو...',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (_) => _search(),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _isLoading ? null : _search,
                  child: _isLoading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Text('جستجو'),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _searchResults.isEmpty && _queryController.text.isNotEmpty
                  ? const Center(child: Text('نتیجه‌ای یافت نشد'))
                  : _searchResults.isEmpty
                  ? const Center(child: Text('عکسی برای جستجو وارد کنید'))
                  : ListView.builder(
                      itemCount: _searchResults.length,
                      itemBuilder: (context, index) {
                        final image = _searchResults[index];
                        return ListTile(
                          title: Text(image.title),
                          subtitle: Text(image.caption),
                          leading: const Icon(Icons.image),
                          trailing: const Icon(
                            Icons.arrow_forward_ios,
                            size: 16,
                          ),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    ImageDetailsScreen(imageId: image.imageId),
                              ),
                            );
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
