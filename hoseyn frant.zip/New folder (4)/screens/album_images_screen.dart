import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import 'image_details_screen.dart';

class AlbumImagesScreen extends StatelessWidget {
  final String albumId;
  const AlbumImagesScreen({super.key, required this.albumId});

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final album = appState.albums.firstWhere((a) => a.albumId == albumId);
    final images = appState.images
        .where((img) => album.imageIds.contains(img.imageId))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('آلبوم: ${album.name}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.home),
            onPressed: () {
              Navigator.pushReplacementNamed(context, '/home');
            },
          ),
        ],
      ),
      body: images.isEmpty
          ? const Center(child: Text('هیچ عکسی در این آلبوم وجود ندارد'))
          : GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              itemCount: images.length,
              itemBuilder: (context, index) {
                final image = images[index];
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            ImageDetailsScreen(imageId: image.imageId),
                      ),
                    );
                  },
                  child: Card(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: image.imageData.isNotEmpty
                              ? Image.memory(
                                  base64Decode(image.imageData),
                                  fit: BoxFit.cover,
                                  width: double.infinity,
                                  errorBuilder: (context, error, stackTrace) {
                                    return const Icon(
                                      Icons.broken_image,
                                      size: 50,
                                    );
                                  },
                                )
                              : const Icon(Icons.image, size: 50),
                        ),
                        Text(
                          image.title,
                          textAlign: TextAlign.center,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
