class ImageItem {
  String imageId;
  String userId;
  String title;
  String caption;
  String uploadDate;
  bool isLiked;
  List<String> tags;
  List<String> albumIds;
  String imageData;
  ImageItem({
    required this.imageId,
    required this.userId,
    required this.title,
    required this.caption,
    required this.uploadDate,
    this.isLiked = false,
    this.tags = const [],
    this.albumIds = const [],
    this.imageData = '',
  });
}
