class Comment {
  String commentId;
  String userId;
  String imageId;
  String commentText;
  String sendTime;

  Comment({
    required this.commentId,
    required this.userId,
    required this.imageId,
    required this.commentText,
    required this.sendTime,
  });
}
