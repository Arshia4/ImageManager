import 'package:flutter/material.dart';
import '../models/user.dart';
import '../models/album.dart';
import '../models/image_item.dart';
import '../models/comment.dart';

class AppState extends ChangeNotifier {
  List<User> users = [];
  List<Album> albums = [];
  List<ImageItem> images = [];
  List<Comment> comments = [];
  User? currentUser;

  bool login(String username, String password) {
    try {
      final user = users.firstWhere(
        (u) => u.username == username && u.password == password,
      );
      currentUser = user;
      notifyListeners();
      return true;
    } catch (e) {
      return false;
    }
  }

  bool register(String username, String password) {
    if (users.any((u) => u.username == username)) {
      return false;
    }
    final newUser = User(
      userId: DateTime.now().millisecondsSinceEpoch.toString(),
      username: username,
      password: password,
    );
    users.add(newUser);
    currentUser = newUser;
    notifyListeners();
    return true;
  }

  void logout() {
    currentUser = null;
    notifyListeners();
  }

  void createAlbum(String name) {
    if (currentUser == null) return;
    final newAlbum = Album(
      albumId: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
    );
    albums.add(newAlbum);
    currentUser!.albumCount = albums.length;
    notifyListeners();
  }

  void deleteAlbum(String albumId) {
    albums.removeWhere((a) => a.albumId == albumId);
    notifyListeners();
  }

  void addImage(ImageItem image) {
    images.add(image);
    if (currentUser != null) {
      currentUser!.imageCount = images.length;
    }
    notifyListeners();
  }

  void deleteImages(List<String> ids) {
    for (final id in ids) {
      images.removeWhere((i) => i.imageId == id);
      for (final album in albums) {
        album.imageIds.removeWhere((i) => i == id);
      }
      comments.removeWhere((c) => c.imageId == id);
    }
    if (currentUser != null) {
      currentUser!.imageCount = images.length;
    }
    notifyListeners();
  }

  void toggleLike(String imageId) {
    final index = images.indexWhere((img) => img.imageId == imageId);
    if (index != -1) {
      images[index].isLiked = !images[index].isLiked;
      notifyListeners();
    }
  }

  void editImageTitle(String imageId, String newTitle) {
    final index = images.indexWhere((img) => img.imageId == imageId);
    if (index != -1) {
      images[index].title = newTitle;
      notifyListeners();
    }
  }

  void editImageCaption(String imageId, String newCaption) {
    final index = images.indexWhere((img) => img.imageId == imageId);
    if (index != -1) {
      images[index].caption = newCaption;
      notifyListeners();
    }
  }

  void editImageTags(String imageId, List<String> newTags) {
    final index = images.indexWhere((img) => img.imageId == imageId);
    if (index != -1) {
      images[index].tags = newTags;
      notifyListeners();
    }
  }

  void addImageToAlbum(String imageId, String albumId) {
    final album = albums.firstWhere((a) => a.albumId == albumId);
    if (!album.imageIds.contains(imageId)) {
      album.imageIds.add(imageId);
      notifyListeners();
    }
  }

  void removeImageFromAlbum(String imageId, String albumId) {
    final album = albums.firstWhere((a) => a.albumId == albumId);
    album.imageIds.removeWhere((i) => i == imageId);
    notifyListeners();
  }

  void addComment(String imageId, Comment comment) {
    comments.add(comment);
    notifyListeners();
  }

  void editComment(String commentId, String newText) {
    final index = comments.indexWhere((c) => c.commentId == commentId);
    if (index != -1) {
      comments[index].commentText = newText;
      notifyListeners();
    }
  }

  void deleteComment(String commentId) {
    comments.removeWhere((c) => c.commentId == commentId);
    notifyListeners();
  }

  List<Comment> getCommentsForImage(String imageId) {
    return comments.where((c) => c.imageId == imageId).toList();
  }

  List<ImageItem> searchImages(String query) {
    return images.where((img) {
      final titleMatch = img.title.contains(query);
      final tagMatch = img.tags.any((tag) => tag.contains(query));
      final captionMatch = img.caption.contains(query);
      return titleMatch || tagMatch || captionMatch;
    }).toList();
  }
}
