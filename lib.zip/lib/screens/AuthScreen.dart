import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLogin = true;

  final RegExp _usernameRegex = RegExp(r'^[a-zA-Z0-9_]{4,16}$');
  final RegExp _passwordRegex = RegExp(
    r'^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$',
  );

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final appState = Provider.of<AppState>(context, listen: false);
      bool success;

      if (_isLogin) {
        success = appState.login(
          _usernameController.text,
          _passwordController.text,
        );
      } else {
        success = appState.register(
          _usernameController.text,
          _passwordController.text,
        );
      }

      if (success) {
        Navigator.pushReplacementNamed(context, '/home');
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _isLogin
                  ? 'نام کاربری یا رمز اشتباه است'
                  : 'این نام کاربری قبلا گرفته شده',
            ),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                _isLogin ? 'ورود به حساب' : 'ثبت نام جدید',
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 32),
              TextFormField(
                controller: _usernameController,
                decoration: const InputDecoration(labelText: 'نام کاربری'),
                validator: (value) {
                  if (value == null || !_usernameRegex.hasMatch(value)) {
                    return '۴ تا ۱۶ کاراکتر انگلیسی یا عدد و زیرخط';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'رمز عبور'),
                validator: (value) {
                  if (value == null || !_passwordRegex.hasMatch(value)) {
                    return 'حداقل ۸ کاراکتر شامل حداقل یک حرف و یک عدد';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _submitForm,
                  child: Text(_isLogin ? 'ورود' : 'ثبت نام'),
                ),
              ),
              TextButton(
                onPressed: () => setState(() => _isLogin = !_isLogin),
                child: Text(
                  _isLogin
                      ? 'ایجاد حساب کاربری جدید'
                      : 'قبلاً ثبت نام کرده‌ام؟ ورود',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
