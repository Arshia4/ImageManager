import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/image_item.dart';
import '../providers/app_state.dart';

class UploadScreen extends StatefulWidget {
  const UploadScreen({super.key});

  @override
  State<UploadScreen> createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController captionController = TextEditingController();
  final TextEditingController tagsController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context, listen: false);

    return Scaffold(
      appBar: AppBar(title: const Text('آپلود عکس')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: 'عنوان عکس'),
            ),
            TextField(
              controller: captionController,
              decoration: const InputDecoration(labelText: 'کپشن'),
            ),
            TextField(
              controller: tagsController,
              decoration: const InputDecoration(
                labelText: 'تگ‌ها (با کاما جدا کن)',
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                final newImage = ImageItem(
                  imageId: DateTime.now().millisecondsSinceEpoch.toString(),
                  userId: appState.currentUser?.userId ?? 'user1',
                  title: titleController.text.isEmpty
                      ? 'بدون عنوان'
                      : titleController.text,
                  caption: captionController.text,
                  uploadDate: DateTime.now().toString(),
                  isLiked: false,
                  tags: tagsController.text
                      .split(',')
                      .map((e) => e.trim())
                      .where((e) => e.isNotEmpty)
                      .toList(),
                  albumIds: [],
                );
                appState.addImage(newImage);
                Navigator.pop(context);
              },
              child: const Text('آپلود'),
            ),
          ],
        ),
      ),
    );
  }
}
