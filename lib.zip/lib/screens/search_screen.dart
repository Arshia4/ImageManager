import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController tagController = TextEditingController();
  final TextEditingController dateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('جستجوی عکس')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(
                labelText: 'عنوان',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: tagController,
                    decoration: const InputDecoration(
                      labelText: 'تگ',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: dateController,
                    decoration: const InputDecoration(
                      labelText: 'تاریخ',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                setState(() {});
              },
              child: const Text('جستجو'),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: appState.images.where((img) {
                  final titleMatch = img.title.contains(titleController.text);
                  final tagMatch =
                      tagController.text.isEmpty ||
                      img.tags.any((tag) => tag.contains(tagController.text));
                  final dateMatch =
                      dateController.text.isEmpty ||
                      img.uploadDate.contains(dateController.text);
                  return titleMatch && tagMatch && dateMatch;
                }).length,
                itemBuilder: (context, index) {
                  final filteredImages = appState.images.where((img) {
                    final titleMatch = img.title.contains(titleController.text);
                    final tagMatch =
                        tagController.text.isEmpty ||
                        img.tags.any((tag) => tag.contains(tagController.text));
                    final dateMatch =
                        dateController.text.isEmpty ||
                        img.uploadDate.contains(dateController.text);
                    return titleMatch && tagMatch && dateMatch;
                  }).toList();

                  final image = filteredImages[index];
                  return ListTile(
                    title: Text(image.title),
                    subtitle: Text(image.caption),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
