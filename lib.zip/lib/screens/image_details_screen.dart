import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/comment.dart';
import '../providers/app_state.dart';

class ImageDetailsScreen extends StatefulWidget {
  final String imageId;
  const ImageDetailsScreen({super.key, required this.imageId});

  @override
  State<ImageDetailsScreen> createState() => _ImageDetailsScreenState();
}

class _ImageDetailsScreenState extends State<ImageDetailsScreen> {
  final TextEditingController commentController = TextEditingController();

  void _showEditDialog(
    BuildContext context,
    String title,
    String hint,
    Function(String) onSave,
  ) {
    final TextEditingController controller = TextEditingController(text: title);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('ویرایش $hint'),
          content: TextField(
            controller: controller,
            decoration: InputDecoration(hintText: hint),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('لغو'),
            ),
            TextButton(
              onPressed: () {
                if (controller.text.isNotEmpty) {
                  onSave(controller.text);
                  Navigator.pop(context);
                }
              },
              child: const Text('ذخیره'),
            ),
          ],
        );
      },
    );
  }

  void _showEditTagsDialog(BuildContext context, List<String> currentTags) {
    final TextEditingController controller = TextEditingController(
      text: currentTags.join(', '),
    );

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('ویرایش تگ‌ها'),
          content: TextField(
            controller: controller,
            decoration: const InputDecoration(
              hintText: 'تگ‌ها (با کاما جدا کن)',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('لغو'),
            ),
            TextButton(
              onPressed: () {
                final newTags = controller.text
                    .split(',')
                    .map((e) => e.trim())
                    .where((e) => e.isNotEmpty)
                    .toList();
                Provider.of<AppState>(
                  context,
                  listen: false,
                ).editImageTags(widget.imageId, newTags);
                Navigator.pop(context);
              },
              child: const Text('ذخیره'),
            ),
          ],
        );
      },
    );
  }

  void _showEditCommentDialog(
    BuildContext context,
    String commentId,
    String currentText,
  ) {
    final TextEditingController editController = TextEditingController(
      text: currentText,
    );

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('ویرایش کامنت'),
          content: TextField(
            controller: editController,
            decoration: const InputDecoration(hintText: 'متن جدید'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('لغو'),
            ),
            TextButton(
              onPressed: () {
                if (editController.text.isNotEmpty) {
                  Provider.of<AppState>(
                    context,
                    listen: false,
                  ).editComment(commentId, editController.text);
                  Navigator.pop(context);
                }
              },
              child: const Text('ذخیره'),
            ),
          ],
        );
      },
    );
  }

  void _showAddToAlbumDialog(BuildContext context, String imageId) {
    final appState = Provider.of<AppState>(context, listen: false);

    if (appState.albums.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('هیچ آلبومی وجود ندارد. ابتدا یک آلبوم بسازید.'),
        ),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('انتخاب آلبوم'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: appState.albums.length,
              itemBuilder: (context, index) {
                final album = appState.albums[index];
                return ListTile(
                  title: Text(album.name),
                  subtitle: Text('${album.imageIds.length} تصویر'),
                  onTap: () {
                    appState.addImageToAlbum(imageId, album.albumId);
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('عکس به آلبوم ${album.name} اضافه شد'),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('لغو'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final image = appState.images.firstWhere(
      (img) => img.imageId == widget.imageId,
      orElse: () => throw Exception('عکس یافت نشد'),
    );
    final comments = appState.getCommentsForImage(widget.imageId);

    return Scaffold(
      appBar: AppBar(
        title: const Text('جزئیات عکس'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              _showEditDialog(
                context,
                image.title,
                'عنوان',
                (newTitle) => appState.editImageTitle(widget.imageId, newTitle),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.add_to_photos),
            onPressed: () {
              _showAddToAlbumDialog(context, widget.imageId);
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 200,
              width: double.infinity,
              color: Colors.grey[300],
              child: Center(
                child: Text(image.title, style: const TextStyle(fontSize: 24)),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              image.title,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Row(
              children: [
                Expanded(child: Text(image.caption)),
                IconButton(
                  icon: const Icon(Icons.edit, size: 18),
                  onPressed: () {
                    _showEditDialog(
                      context,
                      image.caption,
                      'کپشن',
                      (newCaption) =>
                          appState.editImageCaption(widget.imageId, newCaption),
                    );
                  },
                ),
              ],
            ),
            if (image.tags.isNotEmpty)
              Wrap(
                spacing: 8,
                children: image.tags
                    .map((tag) => Chip(label: Text(tag)))
                    .toList(),
              ),
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.edit, size: 18),
                  onPressed: () {
                    _showEditTagsDialog(context, image.tags);
                  },
                ),
                const Text('ویرایش تگ‌ها'),
              ],
            ),
            Text(
              'تاریخ آپلود: ${image.uploadDate}',
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
            Row(
              children: [
                IconButton(
                  onPressed: () {
                    appState.toggleLike(widget.imageId);
                  },
                  icon: Icon(
                    image.isLiked ? Icons.favorite : Icons.favorite_border,
                    color: image.isLiked ? Colors.red : null,
                  ),
                ),
                Text(
                  '${appState.images.firstWhere((img) => img.imageId == widget.imageId).isLiked ? 1 : 0}',
                ),
              ],
            ),
            const Text(
              'کامنت‌ها:',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: comments.length,
                itemBuilder: (context, index) {
                  final comment = comments[index];
                  return ListTile(
                    title: Text('${comment.userId}: ${comment.commentText}'),
                    subtitle: Text(
                      comment.sendTime,
                      style: const TextStyle(fontSize: 10, color: Colors.grey),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit, size: 18),
                          onPressed: () {
                            _showEditCommentDialog(
                              context,
                              comment.commentId,
                              comment.commentText,
                            );
                          },
                        ),
                        IconButton(
                          icon: const Icon(
                            Icons.delete,
                            size: 18,
                            color: Colors.red,
                          ),
                          onPressed: () {
                            appState.deleteComment(comment.commentId);
                          },
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: commentController,
                    decoration: const InputDecoration(
                      hintText: 'کامنت بنویس...',
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () {
                    if (commentController.text.isNotEmpty) {
                      appState.addComment(
                        widget.imageId,
                        Comment(
                          commentId: DateTime.now().millisecondsSinceEpoch
                              .toString(),
                          userId: 'user1',
                          imageId: widget.imageId,
                          commentText: commentController.text,
                          sendTime: DateTime.now().toString(),
                        ),
                      );
                      commentController.clear();
                    }
                  },
                  icon: const Icon(Icons.send),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
